{{/*
This template serves as a blueprint for all Route objects that are created
within the common library.
*/}}
{{- define "bjw-s.common.class.route" -}}
  {{- $rootContext := .rootContext -}}
  {{- $routeObject := .object -}}

  {{- $routeKind := $routeObject.kind | default "HTTPRoute" -}}
  {{- $apiVersion := "gateway.networking.k8s.io/v1alpha2" -}}
  {{- if $rootContext.Capabilities.APIVersions.Has (printf "gateway.networking.k8s.io/v1beta1/%s" $routeKind) }}
    {{- $apiVersion = "gateway.networking.k8s.io/v1beta1" -}}
  {{- end -}}
  {{- if $rootContext.Capabilities.APIVersions.Has (printf "gateway.networking.k8s.io/v1/%s" $routeKind) }}
    {{- $apiVersion = "gateway.networking.k8s.io/v1" -}}
  {{- end -}}
  {{- $labels := mergeOverwrite
    (include "bjw-s.common.lib.metadata.allLabels" $rootContext | fromYaml)
    ($routeObject.labels | default dict)
  -}}
  {{- $annotations := mergeOverwrite
    (include "bjw-s.common.lib.metadata.globalAnnotations" $rootContext | fromYaml)
    ($routeObject.annotations | default dict)
  -}}
---
apiVersion: {{ $apiVersion }}
kind: {{ $routeKind }}
metadata:
  name: {{ $routeObject.name }}
  {{- with $labels }}
  labels:
    {{- range $key, $value := . }}
    {{- printf "%s: %s" $key (include "bjw-s.common.lib.common.renderString" (dict "value" $value "rootContext" $rootContext) | toYaml ) | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- with $annotations }}
  annotations:
    {{- range $key, $value := . }}
    {{- printf "%s: %s" $key (include "bjw-s.common.lib.common.renderString" (dict "value" $value "rootContext" $rootContext) | toYaml ) | nindent 4 }}
    {{- end }}
  {{- end }}
  namespace: {{ $routeObject.namespaceOverride | default $rootContext.Release.Namespace }}
spec:
  parentRefs:
  {{- range $routeObject.parentRefs }}
    {{- $parentRef := . -}}
    {{- $parentGroup := $parentRef.group | default "gateway.networking.k8s.io" -}}
    {{- $parentKind := $parentRef.kind | default "Gateway" -}}
    {{- $parentName := $parentRef.name -}}
    {{- $parentNamespace := $parentRef.namespace -}}
    {{- if $parentRef.identifier -}}
      {{- /* Resolve the parent from a locally generated ListenerSet */ -}}
      {{- $listenerSet := include "bjw-s.common.lib.listenerSet.getByIdentifier" (dict "rootContext" $rootContext "id" $parentRef.identifier) | fromYaml -}}
      {{- if not $listenerSet -}}
        {{- fail (printf "Route '%s': No enabled ListenerSet found with identifier '%s'. Define and enable it under 'listenerSets.%s' or reference a parent Gateway by name." $routeObject.identifier $parentRef.identifier $parentRef.identifier) -}}
      {{- end -}}
      {{- $parentGroup = $listenerSet.group -}}
      {{- $parentKind = $listenerSet.kind -}}
      {{- $parentName = $listenerSet.name -}}
      {{- if not $parentNamespace -}}
        {{- $listenerSetNamespace := $listenerSet.namespaceOverride | default $rootContext.Release.Namespace -}}
        {{- $routeNamespace := $routeObject.namespaceOverride | default $rootContext.Release.Namespace -}}
        {{- if ne $listenerSetNamespace $routeNamespace -}}
          {{- $parentNamespace = $listenerSetNamespace -}}
        {{- end -}}
      {{- end -}}
    {{- end }}
    - group: {{ $parentGroup }}
      kind: {{ $parentKind }}
      name: {{ required (printf "parentRef name is required for %v %v" $routeKind $routeObject.name) $parentName }}
      {{- if $parentNamespace }}
      namespace: {{ $parentNamespace | quote }}
      {{- end }}
      {{- if $parentRef.sectionName }}
      sectionName: {{ $parentRef.sectionName | quote }}
      {{- end }}
      {{- if $parentRef.port }}
      port: {{ $parentRef.port }}
      {{- end }}
  {{- end }}
  {{- if and (ne $routeKind "TCPRoute") (ne $routeKind "UDPRoute") $routeObject.hostnames }}
  hostnames:
    {{- range $routeObject.hostnames }}
    - {{ include "bjw-s.common.lib.common.renderString" (dict "value" . "rootContext" $rootContext) | quote }}
    {{- end }}
  {{- end }}
  rules:
  {{- range $routeObject.rules }}
    - {{ with .name -}}
        name: {{ include "bjw-s.common.lib.common.renderString" (dict "value" . "rootContext" $rootContext) }}
      {{ end -}}
      backendRefs:
      {{- if empty .backendRefs }}
         []
      {{ else -}}
        {{- range .backendRefs -}}
          {{- $service := dict -}}
          {{- $serviceName := "" -}}
          {{- $servicePort := 0 -}}
          {{- if .name -}}
            {{- $serviceName = include "bjw-s.common.lib.common.renderString" (dict "value" .name "rootContext" $rootContext) -}}
          {{- else if .identifier -}}
            {{- $service = (include "bjw-s.common.lib.service.getByIdentifier" (dict "rootContext" $rootContext "id" .identifier) | fromYaml ) -}}
            {{- if not $service -}}
              {{- fail (printf "No enabled Service found with this identifier. (route: '%s', identifier: '%s')" $routeObject.identifier .identifier) -}}
            {{- end -}}
            {{- $serviceName = $service.name -}}
          {{- end -}}
          {{- if empty .port -}}
            {{/*- Default to the Service primary port if no port has been specified -*/}}
            {{- if $service -}}
              {{- $defaultServicePort := include "bjw-s.common.lib.service.primaryPort" (dict "rootContext" $rootContext "serviceObject" $service) | fromYaml -}}
              {{- if $defaultServicePort -}}
                {{- $servicePort = $defaultServicePort.port -}}
              {{- end -}}
            {{- end -}}
          {{- else -}}
            {{/*- If a port number is given, use that -*/}}
            {{- if kindIs "float64" .port -}}
              {{- $servicePort = .port -}}
            {{- else if kindIs "string" .port -}}
              {{/*- If a port name is given, try to resolve to a number -*/}}
              {{- $servicePort = include "bjw-s.common.lib.service.getPortNumberByName" (dict "rootContext" $rootContext "serviceID" $service.identifier "portName" .port) -}}
              {{- if not $servicePort -}}
                {{- fail (printf "No enabled Service Port found with this identifier. (route: '%s', service: '%s', identifier: '%s')" $routeObject.identifier $service.identifier .port) -}}
              {{- end -}}
            {{- end -}}
          {{- end }}
        - group: {{ .group | default "" | quote}}
          kind: {{ .kind | default "Service" }}
          name: {{ $serviceName }}
          namespace: {{ .namespace | default $rootContext.Release.Namespace }}
          {{- if $servicePort }}
          port: {{ $servicePort }}
          {{- end }}
          weight: {{ include "bjw-s.common.lib.defaultKeepNonNullValue" (dict "value" .weight "default" 1) }}
        {{- end }}
      {{- end }}
      {{- if or (eq $routeKind "HTTPRoute") (eq $routeKind "GRPCRoute") }}
        {{- with .matches }}
      matches: {{- toYaml . | nindent 8 }}
        {{- end }}
        {{- with .filters }}
      filters: {{- toYaml . | nindent 8 }}
        {{- end }}
        {{- with .sessionPersistence }}
      sessionPersistence: {{- toYaml . | nindent 8 }}
        {{- end }}
      {{- end }}
      {{- if (eq $routeKind "HTTPRoute") }}
        {{- with .timeouts }}
      timeouts: {{- toYaml . | nindent 8 }}
        {{- end }}
      {{- end }}
  {{- end }}
{{- end }}
